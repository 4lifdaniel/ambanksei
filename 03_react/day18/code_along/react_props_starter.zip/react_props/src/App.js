import React from "react";
import "./App.css";

export default function App() {
  return (
    <div className="App">
      <h1>Bootstrap Cards to Component Example</h1>
    </div>
  );
}