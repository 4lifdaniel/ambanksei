export default [
  {
    img: 'http://res.cloudinary.com/jkeohan/image/upload/v1535732381/day.svg',
    conditions: 'sunny',
    time: 'day'
  },
  {
    img: 'http://res.cloudinary.com/jkeohan/image/upload/v1535732381/night.svg',
    conditions: 'clear',
    time: 'night'
  },
  {
    img:
      'http://res.cloudinary.com/jkeohan/image/upload/v1535732381/stormy.svg',
    condtions: 'shitty',
    time: 'all day'
  },
  {
    img:
      'http://res.cloudinary.com/jkeohan/image/upload/v1535732381/cloudy-day_t7ckxp.svg',
    conditions: 'overcast',
    time: 'day'
  },
  {
    img:
      'http://res.cloudinary.com/jkeohan/image/upload/v1535732381/cloudy-night.svg',
    conditions: 'its dark, can you really tell?',
    time: 'night'
  }
];
