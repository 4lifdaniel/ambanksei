import React from "react";
import Counter from "./Counter";

function App() {
  return (
    <div className="nes-text is-primary">
      <Counter />
    </div>
  );
}

export default App;
