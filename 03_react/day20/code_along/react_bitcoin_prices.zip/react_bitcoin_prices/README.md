# React Router/Bitcoin price checker 

## Description
This app uses react router and the [Coindesk API](https://www.coindesk.com/api/) to get realtime data of bitcoin pricing. Neat, right?

## Installation Instructions

```
git clone <paste URL>
cd react-bitcoin-prices
npm install
code .
npm run start
```
